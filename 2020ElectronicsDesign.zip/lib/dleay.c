#include <dleay.h>
#include <intrins.h>


void Delay1us()		//@24.000MHz
{
	unsigned char i;

	_nop_();
	_nop_();
	i = 3;
	while (--i);
}


void Delay5us(uint k)   //@24.000MHz
{
do
{
Delay1us();
Delay1us();
Delay1us();
Delay1us();
Delay1us();
}
while(--k);
}

void Delay10us(uint k)		//@24.000MHz
{
do
{
Delay1us();
Delay1us();
Delay1us();
Delay1us();
Delay1us();
Delay5us(1);
}
while(--k);
}

void Delay100us(uint k)		//@24.000MHz
{
do
{
Delay1us();Delay1us();Delay1us();Delay1us();Delay1us();
Delay5us(1);
Delay10us(9);
}
while(--k);
}


void Delay1ms(uint k)		//@24.000MHz
{
do
{
Delay10us(10);
Delay100us(9);
}
while(--k);
}
