#ifndef _DLEAY_H_
#define _DLEAY_H_
#include <type_name.h>

void Delay1us();	       	//@12.000MHz
void Delay5us(uint k);    //@12.000MHz
void Delay10us(uint k);		//@12.000MHz
void Delay100us(uint k);	//@12.000MHz
void Delay1ms(uint k);		//@12.000MHz
#endif