//#include <ds1302.h>
//#include <dleay.h>

//uchar RTC[]={0X50,0X59,0X23,0X07,0X05,0X04,0X20}; //�롢�֡�ʱ���ա��¡����ڡ���


//uchar read_ds1302_bit(uchar addr)
//{
//uchar i,dat;
//D_CE=0;D_CLK=0;Delay1us();D_CE=1;
//for(i=0;i<8;i++)
//	{
//  EA=0;
//	D_DAT=addr&0x01;
//	addr>>=1;
//	  D_CLK=1;
//	Delay1us();
//	D_CLK=0;
//	Delay1us();
//	EA=1;
//	}
//for(i=0;i<8;i++)
//	{
//	EA=0;
//	dat>>=1;
//	D_CLK=1;	
//			if(D_DAT)dat|=0x80;
//	Delay1us();
//	D_CLK=0;
//	Delay1us();
//	EA=1;
//	}

//	D_CE=0;
//	D_DAT=0;
//	Delay1us();
//	return dat;
//}	

//void write_ds1302_bit(uchar addr,uchar dat)
//{
//uchar i;
//	D_CE=0;D_CLK=0;Delay1us();D_CE=1;
//for(i=0;i<8;i++)
//	{
//  EA=0;
//	D_DAT=addr&0x01;
//	addr>>=1;
//	  D_CLK=1;
//	Delay1us();
//		D_CLK=0;
//	Delay1us();
//	EA=1;
//	}
//	for(i=0;i<8;i++)
//	{
//  EA=0;
//	D_DAT=dat&0x01;
//	dat>>=1;
//	  D_CLK=1;
//	Delay1us();
//			D_CLK=0;
//	Delay1us();
//	EA=1;
//	}

//	D_CE=0;
//	Delay1us();
//}

//void write_ds1302()
//{
//write_ds1302_bit(0x8E,0X00);
//write_ds1302_bit(0x80,RTC[0]);
//write_ds1302_bit(0x82,RTC[1]);
//write_ds1302_bit(0x84,RTC[2]);
//write_ds1302_bit(0x86,RTC[3]);
//write_ds1302_bit(0x88,RTC[4]);
//write_ds1302_bit(0x8A,RTC[5]);
//write_ds1302_bit(0x8C,RTC[6]);
//write_ds1302_bit(0x8E,0X80);
//}

//void read_ds1302()
//{
//	write_ds1302_bit(0x8E,0X80);
//  RTC[0]=read_ds1302_bit(0x81);
//	RTC[1]=read_ds1302_bit(0x83);
//	RTC[2]=read_ds1302_bit(0x85);
//	RTC[3]=read_ds1302_bit(0x87);
//	RTC[4]=read_ds1302_bit(0x89);
//	RTC[5]=read_ds1302_bit(0x8B);
//	RTC[6]=read_ds1302_bit(0x8D);
//	write_ds1302_bit(0x8E,0X00);
//}