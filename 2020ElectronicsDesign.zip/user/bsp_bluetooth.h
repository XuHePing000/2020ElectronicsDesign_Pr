#ifndef __BSP_BLUETOOTH_H
#define __BSP_BLUETOOTH_H

#include "STC8.h"

#define FOSC            24000000UL
#define BRT             (65536 - FOSC / 115200 / 4)


void Uart2Init();
void Uart2Send(char dat);
void Uart2SendStr(char *p);

#endif /*__BSP_BLUETOOTH_H*/

