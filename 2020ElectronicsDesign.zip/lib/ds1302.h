//#ifndef _DS1302_H_
//#define _DS1302_H_

//#include "STC8.h"
//#include <type_name.h>

//sbit D_CLK = P6^1;
//sbit D_DAT = P6^2;
//sbit D_CE  = P6^3;

//void read_ds1302();
//void write_ds1302();
//void write_ds1302_dat(uchar dat);
//uchar read_ds1302_bit(uchar dat1);
//void write_ds1302_bit(uchar dat1,uchar dat2);


//#endif