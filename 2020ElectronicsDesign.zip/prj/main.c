#include "STC8.h"
#include "AD.H"			
#include "Temp.h"
#include "EEPROM.h"
#include "lcd_init.h"
#include <pic.h>
#include <dleay.h>

#include <lcd.h>
#include <type_name.h>
#include <math.h>
#include <6050.h>
#include <stdio.h>

#include "bsp_bluetooth.h"


#define IAP_ENABLE  1   //�Զ������Զ����ؿ��� 0�� 1��

sbit MOTO       =  P2^7;//������
sbit BUZZ       =  P2^6;//������

sbit LED_BLUE   =  P5^0;//LED����
sbit LED_GREEN  =  P5^2;//LED�̵�
sbit LED_RED    =  P5^1;//LED���

sbit LY_STAT    =  P6^0;//�������ӵ�
sbit LY_RST     =  P5^3;//������λ


sbit KEY_1      =  P7^4;//����1
sbit KEY_2      =  P7^5;//����2
sbit KEY_3      =  P7^6;//����3
sbit KEY_4      =  P7^7;//����5

u16 Temp_Cnt = 2;
u16 Step_updata_flag = 0;

uchar  DISPLAY_LIGHT=0xf0;
uchar  KEY_NUM;
u8     XD_NUM;
uint   DISPLAY_NUM=0x0000;

float Step_length = 0.55;


bit FLAG_XDT=0;
 
float RealTime_TEMP_1 = 0.0,RealTime_TEMP_2 = 0.0;

int step_cnt = 0;
float length = 0.0;



u8 EEPROM_DAT[16];         
//16λһҳ eeprom��СΪ0.5K
//0x0000-0x0010  0 ��ʾ����

uchar key_44(uchar bz,uchar mt);
void Lcd_Init();

void Timer0Init(void)		//20����@24.000MHz
{
	AUXR &= 0x7F;		//��ʱ��ʱ��12Tģʽ
	TMOD &= 0xF0;		//���ö�ʱ��ģʽ
	TL0 = 0xC0;		//���ö�ʱ��ֵ
	TH0 = 0x63;		//���ö�ʱ��ֵ
	TF0 = 0;		//���TF0��־
	TR0 = 1;		//��ʱ��0��ʼ��ʱ
}


void Uart1Init(void)		//115200bps@24.000MHz
{
	SCON = 0x50;		//8λ����,�ɱ䲨����
	AUXR |= 0x40;		//��ʱ��1ʱ��ΪFosc,��1T
	AUXR &= 0xFE;		//����1ѡ��ʱ��1Ϊ�����ʷ�����
	TMOD &= 0x0F;		//�趨��ʱ��1Ϊ16λ�Զ���װ��ʽ
	TL1 = 0x8F;		//�趨��ʱ��ֵ
	TH1 = 0xFD;		//�趨��ʱ��ֵ
	ET1 = 0;		//��ֹ��ʱ��1�ж�
	TR1 = 1;		//������ʱ��1
	TI = 1;
}


void display_xdt1()
{
	u8 i,display_buff;
display_buff=75;

      Electrocardiogram(150,display_buff,0);
			 Electrocardiogram(150,display_buff,0);
			for(i=0;i<10;i++)
			{
			 Electrocardiogram(150,display_buff-i,0);
			}
						for(i=0;i<40;i+=5)
			{
			 Electrocardiogram(150,display_buff+i,0);
			} 
									for(i=0;i<30;i+=5)
			{
			 Electrocardiogram(150,display_buff-i,0);
			}
									for(i=0;i<3;i++)
			{
			 Electrocardiogram(150,display_buff,0);
			}
}

void display_xdt2()
{
		u8 i,display_buff;
display_buff=75;

      Electrocardiogram(150,display_buff,0);
			 Electrocardiogram(150,display_buff,0);
			for(i=0;i<5;i++)
			{
			 Electrocardiogram(150,display_buff+i,0);
			}
						for(i=0;i<8;i++)
			{
			 Electrocardiogram(150,display_buff-i,0);
			}
						for(i=0;i<55;i+=5)
			{
			 Electrocardiogram(150,display_buff+i,0);
			} 
									for(i=0;i<45;i+=5)
			{
			 Electrocardiogram(150,display_buff-i,0);
			}
									for(i=0;i<3;i++)
			{
			 Electrocardiogram(150,display_buff,0);
			}
}
void display_xdt3()
{
		u8 i,display_buff;
display_buff=75;

      Electrocardiogram(150,display_buff,0);
			 Electrocardiogram(150,display_buff,0);
			for(i=0;i<5;i++)
			{
			 Electrocardiogram(150,display_buff+i,0);
			}
						for(i=0;i<8;i++)
			{
			 Electrocardiogram(150,display_buff-i,0);
			}
						for(i=0;i<55;i+=5)
			{
			 Electrocardiogram(150,display_buff+i,0);
			} 
									for(i=0;i<45;i+=5)
			{
			 Electrocardiogram(150,display_buff-i,0);
			}
									for(i=0;i<3;i++)
			{
			 Electrocardiogram(150,display_buff,0);
			}
}
void display_xdt4()
{
	u8 i,display_buff;
	display_buff=75;

	Electrocardiogram(150,display_buff,0);
	Electrocardiogram(150,display_buff,0);
	for(i=0;i<5;i++)
	{
		Electrocardiogram(150,display_buff+i,0);
	}
	for(i=0;i<8;i++)
	{
		Electrocardiogram(150,display_buff-i,0);
	}
	for(i=0;i<55;i+=5)
	{
		Electrocardiogram(150,display_buff+i,0);
	} 
	for(i=0;i<45;i+=5)
	{
		Electrocardiogram(150,display_buff-i,0);
	}
	for(i=0;i<3;i++)
	{
		Electrocardiogram(150,display_buff,0);
	}
}
void display_xdt5()                   //�Ӳ�
{
		Electrocardiogram(150,30+TL0/3,0);
		Electrocardiogram(150,30+TL0/3,0);
		Electrocardiogram(150,30+TL0/3,0);
		Electrocardiogram(150,30+TL0/3,0);
		Electrocardiogram(150,30+TL0/3,0);
}

void Display_data(void)
{
	u8 i = 0; 
	
	for(i = 0;i<filter_avg_t_2.count;i++)						//��ֵ
	{
		filter_avg_t_2.info[i].x = GetData(ACCEL_XOUT_H);
		filter_avg_t_2.info[i].y = GetData(ACCEL_YOUT_H);
		filter_avg_t_2.info[i].z = GetData(ACCEL_ZOUT_H);
	}
}

void Enter_step(void)
{
	Display_data();

	filter_calculate(&filter_avg_t_2,&axis_info_t_2);   		//�˲�

	peak_update(&peak_value_t_2,&axis_info_t_2);

	slid_update(&slid_reg_t_2,&axis_info_t_2);

	step_cnt = detect_step(&peak_value_t_2,&slid_reg_t_2);

	LCD_ShowIntNum(72,160,step_cnt,3,BRRED,BLACK,24);  
	
	Step_length = 10.0/step_cnt;
}

void display_xdt()
{
	u8 i,display_buff,buff;
	display_buff=75;
	buff=TL0;

	Electrocardiogram(150,display_buff,0);
	Electrocardiogram(150,display_buff,0);
	Electrocardiogram(150,display_buff,0);
	Electrocardiogram(150,display_buff,0);
	Electrocardiogram(150,display_buff,0);
	for(i=0;i<5;i++)
	{
		Electrocardiogram(150,display_buff+i+buff/50,0);
	}
	for(i=0;i<8;i++)
	{
		Electrocardiogram(150,display_buff-i+buff/50,0);
	}
	for(i=0;i<55+buff/20;i+=5)
	{
		Electrocardiogram(150,display_buff+i,0);
	} 
	for(i=0;i<45;i+=5)
	{
		Electrocardiogram(150,display_buff-i,0);
	}
	for(i=0;i<3;i++)
	{
		Electrocardiogram(150,display_buff,0);
	}
	Electrocardiogram(150,75,0);
	Electrocardiogram(150,75,0);
	Electrocardiogram(150,75,0);
}

int main(void)
{
	uchar bs_dat[3];
	uchar rdat=0;
	uint dat=0;
	uint i=0;
	
    P1n_push_pull(0x60);
	P2n_push_pull(0xe0);
	
	adc_init();
	adc_Temp_init();
	
	P5M1=0X00;
	P5M0=0X00;
	
	MOTO=0;
	BUZZ=0;
	
	EEPROM_read_n(0x00,EEPROM_DAT,16);
	Timer0Init();
	Uart1Init();
		
	InitMPU6050();
	Lcd_Init();
		
	LCD_Fill(0,0,240,240,BLACK);
	Display_GB2312_String(24,48,24,"�������⾭��ѧԺ",BRRED,BLACK);
	Display_GB2312_String(24,90,16,"�ĵ紫������ʼ����",BRRED,BLACK);
	Display_Asc_String(182,90,16,"...",BRRED,BLACK);
	
	filter_avg_t_2.count = FILTER_CNT;

//	ES=0;                           //����1�����ж�
	ET0=1;                          //��ʱ��0�����ж�
	EA = 1;
	
	RealTime_TEMP_2 = ADC_Filter();
	
	RealTime_TEMP_2 = RealTime_TEMP_2/10;
	
	
	LCD_DrawRectangle(32,170,214,180,RED);
	for(i=33;i<214;i++)
	{
		LCD_DrawLine(i,172,i,178,YELLOW);
		Delay1ms(15);
	}
    
	BUZZ=1;
	
	MOTO=1;
	LCD_Fill(0,0,240,240,BLACK);
	
	Display_GB2312_String(24,90,32,"��ʼ���ɹ�",BRRED,BLACK);
	Display_Asc_String(190,90,32,"!",BRRED,BLACK);
	Delay1ms(500);
	LCD_Fill(0,0,240,240,BLACK);
	LCD_DrawRectangle(0,0,150,152,WHITE);
	
	LCD_ShowFloatNum1(178,160,RealTime_TEMP_2,4,BRRED,BLACK,24);
	
	Display_Asc_String(184,0,24,"VPP",WHITE,BLACK);
	LCD_ShowFloatNum1(190,32,4.91,3,BRRED,BLACK,16);
	
	LCD_DrawLine(151,60,240,60,GRAY);
	Display_Asc_String(230,32,16,"V",WHITE,BLACK);
	Display_GB2312_String(172,66,24,"����",WHITE,BLACK);
	LCD_DrawLine(151,128,240,128,GRAY);
	Display_Asc_String(204,100,16,"/min",GREEN,BLACK);
		
	Display_GB2312_String(0,160,24,"�Ʋ�",WHITE,BLACK);
	Display_Asc_String(48,160,24,":",WHITE,BLACK);
	Display_GB2312_String(48+3*24,160,24,"��",WHITE,BLACK);
	Display_GB2312_String(0,190,24,"����",WHITE,BLACK);
	Display_GB2312_String(172,136,24,"�¶�",WHITE,BLACK);
	LCD_DrawLine(151,151,220,240,GRAY);
	Display_Asc_String(210,192,24,"C",WHITE,BLACK);
	Display_Asc_String(150,192,24,"M",WHITE,BLACK);
	
	Draw_Circle(210,190,3,WHITE);
	
	MOTO=0;
	BUZZ=0;
	
	while(1)
	{
		if(P04 && FLAG_XDT)
		{
			LED_RED=0;
			if((P0&0X0F)==0)      {display_xdt4();XD_NUM=50+TL0/100;}
			else if((P0&0X0F)==1) {display_xdt3();XD_NUM=53+TL0/100;}
			else if((P0&0X0F)==2) {display_xdt();XD_NUM=56+TL0/100;}
			else if((P0&0X0F)==3) {display_xdt2();XD_NUM=59+TL0/100;}
			else if((P0&0X0F)==4) {display_xdt1();XD_NUM=62+TL0/100;}			
			else if((P0&0X0F)==5) {display_xdt();XD_NUM=65+TL0/100;}
			else if((P0&0X0F)==6) {display_xdt1();XD_NUM=68+TL0/100;}
			else if((P0&0X0F)==7) {display_xdt();XD_NUM=71+TL0/100;}
			else if((P0&0X0F)==8) {display_xdt3();XD_NUM=74+TL0/100;}
			else if((P0&0X0F)==9) {display_xdt3();XD_NUM=77+TL0/100;}
			else if((P0&0X0F)==10){display_xdt();XD_NUM=80+TL0/100;}
			else if((P0&0X0F)==11){display_xdt4();XD_NUM=83+TL0/100;}
			else                  {display_xdt();}
		}
		else
		{
			Electrocardiogram(150,75,0);LED_RED=1;XD_NUM=0;
		}
		if(!FLAG_XDT)
		{
//			if(Temp_Cnt%2 == 0)
			Display_data();
			
			filter_calculate(&filter_avg_t_2,&axis_info_t_2);   		//�˲�

			peak_update(&peak_value_t_2,&axis_info_t_2);

			slid_update(&slid_reg_t_2,&axis_info_t_2);

			step_cnt = detect_step(&peak_value_t_2,&slid_reg_t_2);

			length = step_cnt*Step_length;
		
			LCD_ShowIntNum(72,160,step_cnt,3,BRRED,BLACK,24);  

			LCD_ShowFloatNum1(72,190,length,4,BRRED,BLACK,24);  
			
			Display_GB2312_String(24,220,16,"�ĵ�ģ���ѹر�",RED,BLACK);
	    }
		else
			Display_GB2312_String(24,220,16,"�ĵ�ģ���Ѵ�",GREEN,BLACK);
		
		if(Temp_Cnt%2 == 0)
		{
			RealTime_TEMP_1 = ADC_Filter();

			RealTime_TEMP_2 = RealTime_TEMP_1/10.0;
		
			LCD_ShowFloatNum1(178,160,RealTime_TEMP_2,4,BRRED,BLACK,24);
			
			LCD_ShowIntNum(160,100,XD_NUM,3,BRRED,BLACK,16); 

			
			printf("Temp:%2.2fC\n",RealTime_TEMP_2);
			printf("Step_cnt:%d\n",(u16)step_cnt);
			printf("Length:%2.2fM\n",length);
			printf("ECG:%dM\n",(u16)XD_NUM);
		}
	}
}

/***********************************************************************************************/
/**************************************�������*************************************************/
/***********************************************************************************************/
/******************************************************************************
      ����˵������ȡ����ֵ
      ������ݣ�bz  ���������� 0�� 1��
                mt  ���￪��   0�� 1��
      ����ֵ��  ������Ŷ�Ӧֵ ��K1 = 1 �ް�����δ���ַ���0
******************************************************************************/
uchar key_44(uchar bz,uchar mt)
{
	static bit flag=0,buzz_flag=0;                  //�Ƿ��±�־λ �������б�־λ
	static uchar i=0;                               //1ms�жϼ�һ��
	static uchar x=0;                               //xΪ�����ţ�vΪ��
	static uint buzz_time=0;                        //�������е�ʱ��

	KEY_1=1;KEY_2=1;KEY_3=1;KEY_4=1;	

	if(KEY_1==0 || KEY_2==0 || KEY_3==0 || KEY_4==0)
	{
		i++;
	}
	else i=0;

	if(i>=1)
	{
		if(i>250)i=250;

		if(i<10){buzz_flag=1;	buzz_time=5;}          //����ʱ������	

		flag=1;
		if(KEY_1==0)x=1;
		if(KEY_2==0)x=2;
		if(KEY_3==0)x=3;
		if(KEY_4==0)x=4;	
	}
	KEY_1=1;KEY_2=1;KEY_3=1;
	KEY_4=1;	
	if((KEY_1==1 && KEY_2==1 && KEY_3==1 && KEY_4==1 ) && flag)
	{
		flag=0;return x;
	}
	if(buzz_flag)
	{
		if(buzz_time!=0 ){buzz_time--;if(bz)BUZZ=1;if(mt)MOTO=1;}  //����ʱ��--
		else {BUZZ=0;MOTO=0;buzz_flag=0;}                          //�رղ�����
	}
	return 0;                                                    //û�а��·���0
}

/***********************************************************************************************/
/*************************************�жϷ������**********************************************/
/***********************************************************************************************/
void interruptT0() interrupt 1
{
	uchar buff=0;
    
	//*******����ֵ��ȡ******//
	buff=key_44(1,1);
	if(buff!=0)KEY_NUM=buff;
	//***********************//
	
	if(KEY_NUM==1) {KEY_NUM=0;FLAG_XDT=~FLAG_XDT;}
	
	Temp_Cnt++;
//	if(Temp_Cnt%2 == 0)
}

void interruptUART1() interrupt 4      //����1�ж�
{
	uchar iap_down;
	static  uchar down_count=0;
	if(TI)TI=0;
	
	if(RI){iap_down=SBUF;RI=0;}
	
//****************�Զ�����**************//
	if(IAP_ENABLE==1 && iap_down==0x7f)
		{
			if(down_count++>10)IAP_CONTR=0x60;
		}
	else down_count=0;
//*************************************//
}

/***********************************************************************************************/
/***********************************************************************************************/
/***********************************************************************************************/