#ifndef _TYPE_NAME_H_
#define _TYPE_NAME_H_

typedef unsigned int   uint;
typedef unsigned char  uchar;

#define u8  unsigned char
#define u16 unsigned int
#define u32 unsigned long int



#endif